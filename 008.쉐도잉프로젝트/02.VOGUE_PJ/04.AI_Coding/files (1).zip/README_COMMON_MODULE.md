# 보그 코리아 공통 모듈 사용 가이드

## 📁 폴더 구조

```
project/
├── inc/
│   ├── header.html    # 상단 헤더 공통 모듈
│   └── footer.html    # 하단 푸터 공통 모듈
├── js/
│   ├── common.js      # 공통 모듈 로드 스크립트
│   ├── main.js        # 메인 페이지 기능
│   └── main_data_binding.js
├── css/
│   └── main.css
├── index.html         # 메인 페이지
└── fashion.html       # 서브페이지 예제
```

## 🚀 공통 모듈 작동 원리

### 1. header.html (상단 영역)
- 로고
- 언어 선택 버튼
- 구독하기 버튼
- 메뉴 버튼
- GNB 네비게이션

### 2. footer.html (하단 영역)
- 푸터 로고
- 푸터 링크
- 저작권 정보

### 3. common.js (로드 스크립트)
jQuery의 `load()` 메서드를 사용하여 공통 모듈을 동적으로 불러옵니다.

```javascript
$(document).ready(function() {
  // 헤더 로드
  $("#header-area").load("./inc/header.html");
  
  // 푸터 로드
  $("#footer-area").load("./inc/footer.html");
});
```

## 📝 새 페이지 만들기

서브페이지를 만들 때는 다음 구조를 사용하세요:

```html
<!DOCTYPE html>
<html lang="ko">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>페이지 제목 - VOGUE Korea</title>
    
    <!-- 필수 CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link rel="stylesheet" href="./css/main.css" />

    <!-- 필수 JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="./js/common.js"></script>
  </head>
  <body>
    <!-- 헤더 영역 (자동 로드) -->
    <div id="header-area"></div>

    <!-- 메인 컨텐츠 -->
    <main>
      <!-- 여기에 페이지 내용 작성 -->
    </main>

    <!-- 푸터 영역 (자동 로드) -->
    <div id="footer-area"></div>
  </body>
</html>
```

## ⚠️ 주의사항

1. **jQuery 필수**: common.js는 jQuery를 사용하므로 반드시 jQuery CDN을 먼저 로드해야 합니다.

2. **순서 중요**: 
   ```html
   <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
   <script src="./js/common.js"></script>
   ```

3. **경로 확인**: 
   - inc 폴더와 js 폴더가 같은 레벨에 있어야 합니다
   - 서브 폴더에 페이지를 만들 경우 상대 경로를 조정하세요
   - 예: `../inc/header.html`, `../js/common.js`

4. **CSS 적용**: 
   - header와 footer의 스타일은 main.css에 정의되어 있습니다
   - main.css를 먼저 로드해야 스타일이 올바르게 적용됩니다

## 🔧 공통 모듈 수정하기

### 헤더 수정
`inc/header.html` 파일을 수정하면 모든 페이지의 헤더가 일괄 변경됩니다.

### 푸터 수정
`inc/footer.html` 파일을 수정하면 모든 페이지의 푸터가 일괄 변경됩니다.

### 장점
- 한 번의 수정으로 모든 페이지에 적용
- 유지보수 용이
- 일관성 있는 레이아웃 유지

## 📌 예제 페이지

- `index.html`: 메인 페이지
- `fashion.html`: 패션 서브페이지 예제

fashion.html을 참고하여 다른 서브페이지들을 만들 수 있습니다.
