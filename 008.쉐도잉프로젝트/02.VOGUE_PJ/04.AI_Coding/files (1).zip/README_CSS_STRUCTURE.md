# 보그 코리아 CSS 구조 가이드

## 📁 CSS 파일 구조

```
css/
├── core.css       # 웹폰트 (Roboto, Noto Sans KR)
├── reset.css      # CSS 초기화
├── common.css     # 공통 스타일 (Header, Footer) ⭐ 새로 생성
└── main.css       # 메인 페이지 스타일
```

## 🎨 CSS 파일 설명

### 1. core.css
- Google Fonts CDN을 통한 웹폰트 로드
- Roboto, Roboto Condensed, Noto Sans KR

### 2. reset.css
- CSS 초기화
- 기본 스타일 설정 (body, a, img, ul, li)

### 3. common.css ⭐ **공통 모듈**
**포함된 스타일:**
- Header (헤더)
  - 로고
  - 상단 메뉴 (언어, 구독, 메뉴 버튼)
  - GNB 네비게이션
  
- Footer (푸터)
  - 푸터 로고
  - 푸터 링크
  - 저작권 정보

- 반응형 스타일
  - 태블릿 (820px ~ 1024px)
  - 모바일 (<819px)

### 4. main.css
**포함된 스타일:**
- 히어로 섹션
- Today's Stories
- Best Stories
- Must Read
- People Now
- Fashion/Beauty/Living/Culture 섹션
- Latest Stories
- 각 섹션별 반응형 스타일

## 📝 CSS Import 순서

main.css에서 다음 순서로 import:

```css
@import "./core.css";     /* 1. 웹폰트 */
@import "./reset.css";    /* 2. CSS 초기화 */
@import "./common.css";   /* 3. 공통 스타일 (Header, Footer) */
/* 4. 나머지 메인 페이지 스타일 */
```

## 🔧 CSS 수정 가이드

### Header/Footer 스타일 수정
→ `common.css` 수정
- 모든 페이지에 일괄 적용됨
- 반응형 스타일도 포함

### 메인 페이지 스타일 수정
→ `main.css` 수정
- 각 섹션별 스타일
- 페이지 레이아웃

### 새 페이지 만들 때
공통 스타일만 필요한 경우:
```html
<link rel="stylesheet" href="./css/core.css" />
<link rel="stylesheet" href="./css/reset.css" />
<link rel="stylesheet" href="./css/common.css" />
```

메인 페이지와 같은 스타일이 필요한 경우:
```html
<link rel="stylesheet" href="./css/main.css" />
```
(main.css가 core, reset, common을 자동으로 import함)

## ✅ CSS 분리의 장점

1. **유지보수 편리**
   - Header/Footer는 common.css만 수정
   - 코드 중복 제거

2. **재사용성**
   - 새 페이지에서 common.css만 import 가능
   - 필요한 스타일만 선택적으로 로드

3. **가독성 향상**
   - 파일별로 역할이 명확히 구분됨
   - 코드 찾기 쉬움

4. **협업 용이**
   - 공통 영역과 개별 페이지 영역이 분리됨
   - 충돌 최소화

## 📊 파일 크기

- **common.css**: 174줄 (Header + Footer 공통 스타일)
- **main.css**: 890줄 (메인 페이지 전용 스타일)
- **원본 통합 파일**: 1,062줄

→ 약 172줄(16%)을 common.css로 분리

## ⚠️ 주의사항

1. **Import 순서 중요**
   - core.css → reset.css → common.css 순서 유지
   - common.css는 reset.css 이후에 로드되어야 함

2. **경로 확인**
   - 서브 폴더에 페이지 생성 시 상대 경로 조정 필요
   - 예: `../css/common.css`

3. **캐시 문제**
   - CSS 수정 후 브라우저 캐시 삭제 권장
   - Ctrl + F5 (강력 새로고침)

## 🎯 실전 예제

### 예제 1: Fashion 서브페이지 (common만 사용)
```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <link rel="stylesheet" href="./css/core.css" />
  <link rel="stylesheet" href="./css/reset.css" />
  <link rel="stylesheet" href="./css/common.css" />
  <!-- 페이지 전용 스타일 -->
  <link rel="stylesheet" href="./css/fashion.css" />
</head>
```

### 예제 2: 메인 페이지 (main 사용)
```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <!-- main.css가 core, reset, common을 자동 import -->
  <link rel="stylesheet" href="./css/main.css" />
</head>
```
