# 보그 코리아 Category 페이지 가이드

## 📄 페이지 소개

**category.html**은 SPA(Single Page Application) 방식으로 구성된 서브페이지입니다.
탭 클릭과 페이지네이션을 통해 페이지 새로고침 없이 컨텐츠를 동적으로 로드합니다.

## 📁 파일 구조

```
├── category.html          # 메인 HTML 파일
├── css/
│   └── category.css      # 페이지 전용 스타일
└── js/
    └── category.js       # SPA 기능 구현
```

## 🎯 주요 기능

### 1. 탭 네비게이션
- **전체 / Fashion / Beauty / Living / Culture**
- 탭 클릭 시 컨텐츠 영역이 동적으로 변경
- 페이지 새로고침 없이 부드러운 전환

### 2. 동적 컨텐츠 로드
- 카테고리 선택에 따라 컨텐츠 필터링
- 로딩 애니메이션 표시
- AJAX 방식으로 데이터 로드 (현재는 더미 데이터)

### 3. 페이지네이션
- 이전/다음 버튼
- 페이지 번호 클릭
- 활성 페이지 표시
- 스크롤 자동 이동

## 💻 코드 구조

### HTML 구조
```html
<!-- 헤더 (공통 모듈) -->
<div id="header-area"></div>

<main class="category-main">
  <!-- 탭 네비게이션 -->
  <section class="category-tabs">
    <button class="tab-btn active" data-category="all">전체</button>
    <button class="tab-btn" data-category="fashion">Fashion</button>
    <!-- ... -->
  </section>

  <!-- 카테고리 타이틀 -->
  <section class="category-header">
    <h1 class="category-title">ALL STORIES</h1>
    <p class="category-description">설명</p>
  </section>

  <!-- 컨텐츠 영역 (동적 로드) -->
  <section class="category-content">
    <div class="content-container">
      <!-- 여기에 동적으로 컨텐츠 로드 -->
    </div>
  </section>

  <!-- 페이지네이션 -->
  <section class="category-pagination">
    <!-- 페이지 번호 -->
  </section>
</main>

<!-- 푸터 (공통 모듈) -->
<div id="footer-area"></div>
```

### JavaScript 주요 함수

#### 1. 탭 클릭 이벤트
```javascript
$('.tab-btn').on('click', function() {
  const category = $(this).data('category');
  updateCategoryTitle(category);
  loadCategoryContent(category);
});
```

#### 2. 카테고리 타이틀 업데이트
```javascript
function updateCategoryTitle(category) {
  // 카테고리에 맞는 타이틀과 설명 변경
}
```

#### 3. 컨텐츠 로드
```javascript
function loadCategoryContent(category) {
  // 로딩 표시
  // AJAX로 데이터 가져오기
  // 컨텐츠 렌더링
}
```

## 🔧 실제 데이터 연동 방법

현재는 더미 데이터를 사용하고 있습니다. 실제 데이터 연동을 위해서는:

### 방법 1: JSON 파일 사용
```javascript
function loadCategoryContent(category) {
  $.ajax({
    url: `./data/${category}_data.json`,
    method: 'GET',
    success: function(data) {
      renderArticles(data.articles);
    },
    error: function(error) {
      console.error('데이터 로드 실패:', error);
    }
  });
}
```

### 방법 2: API 연동
```javascript
function loadCategoryContent(category) {
  $.ajax({
    url: `https://api.vogue.co.kr/articles?category=${category}`,
    method: 'GET',
    headers: {
      'Authorization': 'Bearer YOUR_TOKEN'
    },
    success: function(data) {
      renderArticles(data.articles);
    }
  });
}
```

### 방법 3: 기존 JSON 데이터 활용
```javascript
// vogue_korea_data.json 활용
import data from './data/vogue_korea_data.json' with { type: 'json' };

function loadCategoryContent(category) {
  let articles;
  
  if (category === 'all') {
    // 모든 섹션의 article 합치기
    articles = [
      ...data.sections.todaysStories.articles,
      ...data.sections.bestStories.articles,
      ...data.sections.mustRead.articles
    ];
  } else {
    // 특정 카테고리의 article
    articles = data.sections[category].articles;
  }
  
  renderArticles(articles);
}
```

## 🎨 CSS 커스터마이징

### 탭 스타일 변경
```css
.tab-btn.active::after {
  background: #e31e61; /* 보그 메인 컬러 */
}
```

### 그리드 레이아웃 변경
```css
.content-container {
  grid-template-columns: repeat(4, 1fr); /* 4열로 변경 */
}
```

### 카드 호버 효과 변경
```css
.article-card:hover {
  transform: translateY(-10px); /* 더 높게 올리기 */
  box-shadow: 0 10px 30px rgba(0,0,0,0.1); /* 그림자 추가 */
}
```

## 📱 반응형 디자인

### 태블릿 (820px ~ 1024px)
- 2열 그리드
- 탭 간격 조정

### 모바일 (<819px)
- 1열 그리드
- 탭 가로 스크롤
- 버튼 크기 축소

## 🚀 확장 가능성

### 1. 필터 추가
```javascript
// 정렬 필터 추가
<select class="sort-filter">
  <option value="latest">최신순</option>
  <option value="popular">인기순</option>
</select>
```

### 2. 검색 기능
```javascript
// 검색 바 추가
<input type="text" class="search-input" placeholder="검색...">
```

### 3. 무한 스크롤
```javascript
$(window).scroll(function() {
  if ($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
    loadMoreContent();
  }
});
```

### 4. 북마크 기능
```javascript
// 북마크 버튼 추가
<button class="bookmark-btn">
  <i class="fa-regular fa-bookmark"></i>
</button>
```

## ⚠️ 주의사항

1. **jQuery 필수**
   - category.js는 jQuery를 사용합니다
   - jQuery 로드 후 category.js 로드

2. **공통 모듈 의존성**
   - common.js 필요 (header, footer 로드)
   - common.css 필요 (공통 스타일)

3. **이미지 경로**
   - 현재는 실제 보그 이미지 URL 사용
   - 로컬 이미지 사용 시 경로 수정 필요

4. **데이터 구조**
   - 현재 더미 데이터 사용
   - 실제 데이터 연동 시 구조 확인 필요

## 📊 성능 최적화

### 이미지 Lazy Loading
```javascript
<img loading="lazy" src="..." alt="...">
```

### 디바운싱 적용
```javascript
let debounceTimer;
$('.search-input').on('input', function() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    searchArticles($(this).val());
  }, 300);
});
```

## 🔗 참고 링크

- [jQuery 공식 문서](https://jquery.com/)
- [SPA 개발 가이드](https://developer.mozilla.org/ko/docs/Glossary/SPA)
- [AJAX 튜토리얼](https://api.jquery.com/jquery.ajax/)
